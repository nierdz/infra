#include <iostream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <fstream>

using namespace std;


void crypt_file(string sAlphabet, string sCle, char* cFile)
{
    string sFile_Line;
    string sLigne_chiffre;
    string sFile_chiffre = "";

    ifstream file_read(cFile, ios::in);

    while (! file_read.eof())
    {
            sLigne_chiffre = "";
            getline(file_read, sFile_Line);

            sFile_Line = sFile_Line+"\n";

            for(int i = 0; i < sFile_Line.size(); i++)
            {
                    sLigne_chiffre = sLigne_chiffre + sFile_Line[i]; // si le caractere n est pas present dans la cle

                    for(int j = 0; j < sAlphabet.size(); j++)
                    {
                            if(sFile_Line[i] == sAlphabet[j])
                            {
                                    sLigne_chiffre[i] = sCle[j];
                            }
                    }
            }

            sFile_chiffre = sFile_chiffre + sLigne_chiffre;
    }

        sFile_chiffre.resize(sFile_chiffre.size()-1); //suppression du caractere en trop

    file_read.close();

    cout<<sFile_chiffre;
}


void decrypt_file(string sAlphabet, string sCle, char* cFile)
{
    string sFile_Line;
    string sLigne_dechiffre;
    string sFile_dechiffre = "";

    ifstream file_read(cFile, ios::in);

    while (! file_read.eof())
    {
        sLigne_dechiffre = "";
        getline(file_read, sFile_Line);

        sFile_Line = sFile_Line+"\n";

        for(int i = 0; i < sFile_Line.size(); i++)
        {
                sLigne_dechiffre = sLigne_dechiffre + sFile_Line[i]; // si le caractere n est pas present dans la cle

                for(int j = 0; j < sAlphabet.size(); j++)
                {
                        if(sFile_Line[i] == sCle[j])
                        {
                                sLigne_dechiffre[i] = sAlphabet[j];
                        }
                }
        }

        sFile_dechiffre = sFile_dechiffre + sLigne_dechiffre;
    }

    file_read.close();

        sFile_dechiffre.resize(sFile_dechiffre.size()-1); //suppression du caractere en trop

    cout<<sFile_dechiffre;
}


void crypt_string(string sAlphabet, string sCle, char* cString, bool bNewline)
{
    string sString_crypt = "";

    for(int i = 0; i < strlen(cString); i++)
    {
        sString_crypt = sString_crypt + cString[i]; // si le caractere n est pas present dans la cle

        for(int j = 0; j < sAlphabet.size(); j++)
        {
            if(cString[i] == sAlphabet[j])
            {
                sString_crypt[i] = sCle[j];
            }
        }
    }

        if(bNewline == 1)
        {
                cout<<sString_crypt<<endl;
        }
        else
        {
                cout<<sString_crypt;
        }
}


void decrypt_string(string sAlphabet, string sCle, char* cString, bool bNewline)
{
    string sString_decrypt = "";

    for(int i = 0; i < strlen(cString); i++)
    {
        sString_decrypt = sString_decrypt + cString[i]; // si le caractere n est pas present dans la cle

        for(int j = 0; j < sAlphabet.size(); j++)
        {
            if(cString[i] == sCle[j])
            {
                sString_decrypt[i] = sAlphabet[j];
            }
        }
    }

        if(bNewline == 1)
        {
                cout<<sString_decrypt<<endl;
        }
        else
        {
                cout<<sString_decrypt;
        }
}

int main(int argc, char *argv[])
{
        bool bNewline = 1;
    int iProblem = 0;
    char *cFarg1;
    char *cFarg2;
    char *cString;
    char *cFile;
    string sAlphabet = "abcdefghijklmnopqrstuvwxyz0123456789_-:/.&=?\n*|!#%ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    string sCle      = "XLla1DpWC.q0d*BMbx7?AKh#uY6VRsiw&S/m|_5N%EZItU\n9!2cfOjr=FngP:e3GQyk-o4JvTzH8";


    if(argv[1] != NULL && argv[2] != NULL)
    {
        if((strcmp(argv[1], "-c") == 0 || strcmp(argv[1], "-d") == 0) && argv[3] == NULL)
        {
            cFarg1  = argv[1];
            cString = argv[2];
            
            if(strcmp(cFarg1, "-c") == 0)
            {
                crypt_string(sAlphabet, sCle, cString, bNewline);
            }
            
            if(strcmp(cFarg1, "-d") == 0)
            {
                decrypt_string(sAlphabet, sCle, cString, bNewline);
            }
        }
        else if((strcmp(argv[1], "-c") == 0 || strcmp(argv[1], "-d") == 0) && strcmp(argv[2], "-n") == 0 && argv[3] != NULL)
        {
            cFarg1  = argv[1];
            cString = argv[3];
                        bNewline = 0;
            
            if(strcmp(cFarg1, "-c") == 0)
            {
                crypt_string(sAlphabet, sCle, cString, bNewline);
            }
            
            if(strcmp(cFarg1, "-d") == 0)
            {
                decrypt_string(sAlphabet, sCle, cString, bNewline);
            }
        }
        else if((strcmp(argv[1], "-c") == 0 || strcmp(argv[1], "-d") == 0) && strcmp(argv[2], "-f") == 0 && argv[3] != NULL)
        {
            cFarg1 = argv[1];
            cFile  = argv[3];
            
            if(strcmp(cFarg1, "-c") == 0)
            {
                crypt_file(sAlphabet, sCle, cFile);
            }
            
            if(strcmp(cFarg1, "-d") == 0)
            {
                decrypt_file(sAlphabet, sCle,  cFile);
            }
        }
        else
        {
            iProblem++;
        }
    }
    else
    {
        iProblem++;
    }

    
    if(iProblem > 0)
    {
        cout<<"USAGE:"<<endl;
        cout<<"minicrypt -c \"string\" => crypt a string"<<endl;
        cout<<"minicrypt -d \"string\" => decrypt a string"<<endl;
        cout<<"minicrypt -c -n \"string\" => crypt a string and no newline"<<endl;
        cout<<"minicrypt -d -n \"string\" => decrypt a string and no newline"<<endl;
        cout<<"minicrypt -c -f file => crypt a file"<<endl;
        cout<<"minicrypt -d -f file => decrypt a file"<<endl;
        
        return 1;
    }
    
    return 0;
}

